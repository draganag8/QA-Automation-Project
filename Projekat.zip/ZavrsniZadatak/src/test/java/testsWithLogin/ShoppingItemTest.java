package testsWithLogin;

import org.testng.annotations.Test;
import pages.*;
import utilities.PropertyManager;

public class ShoppingItemTest extends BaseTestWithLogin{
    @Test
    public void shoppingItemTest () {
        HomePage homePage = new HomePage(driver);
        homePage.addItemToTheCart();
        homePage.navigateToShoppingCart();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.shoppingItem();
        CheckoutStep1Page checkoutStep1Page = new CheckoutStep1Page(driver);
        checkoutStep1Page.performShopping(PropertyManager.getInstance().getFirstName(),
                PropertyManager.getInstance().getLastName(),
                PropertyManager.getInstance().getPostalCode());

        CheckoutStep2Page checkoutStep2Page = new CheckoutStep2Page(driver);
        checkoutStep2Page.finishShopping();

        CheckoutStep3Page checkoutStep3Page = new CheckoutStep3Page(driver);
        checkoutStep3Page.verifyShoppingItem("Thank you for your order!");
    }
}
