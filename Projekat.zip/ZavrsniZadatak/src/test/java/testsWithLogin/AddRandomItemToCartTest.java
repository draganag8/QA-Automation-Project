package testsWithLogin;

import org.testng.annotations.Test;
import pages.HomePage;
import pages.ShoppingCartPage;

public class AddRandomItemToCartTest extends BaseTestWithLogin{

    @Test
    public void addRandomItem(){
        HomePage homePage = new HomePage(driver);
        String addedItemName = homePage.addRandomItemToCart();
        homePage.navigateToShoppingCart();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.verifySpecificItemIsInCart(addedItemName);
    }
}
