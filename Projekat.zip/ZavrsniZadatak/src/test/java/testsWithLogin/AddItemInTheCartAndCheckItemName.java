package testsWithLogin;

import org.testng.annotations.Test;
import pages.HomePage;
import pages.ShoppingCartPage;

public class AddItemInTheCartAndCheckItemName extends BaseTestWithLogin{
    @Test
    public void addItemToTheCart (){
        HomePage homePage = new HomePage(driver);
        homePage.addItemToTheCart();
        homePage.navigateToShoppingCart();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.verifyAddedItemName("Sauce Labs Backpack");
    }
}
