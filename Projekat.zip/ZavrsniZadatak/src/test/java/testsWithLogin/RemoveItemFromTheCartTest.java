package testsWithLogin;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import pages.BasePage;
import pages.HomePage;
import pages.ShoppingCartPage;

public class RemoveItemFromTheCartTest extends BaseTestWithLogin{
    @Test
    public void addItemToCart () throws InterruptedException {
        HomePage homePage = new HomePage(driver);
        homePage.addItemToTheCart();
        homePage.navigateToShoppingCart();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.removeItemFromTheCart();
        shoppingCartPage.verifyRemovedItem();












    }
}
