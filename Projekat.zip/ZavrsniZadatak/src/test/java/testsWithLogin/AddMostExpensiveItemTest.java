package testsWithLogin;

import org.testng.annotations.Test;
import pages.HomePage;
import pages.ShoppingCartPage;

public class AddMostExpensiveItemTest extends BaseTestWithLogin{
    @Test
    public void addMostExpensiveItem (){
        HomePage homePage = new HomePage(driver);
        String itemName = homePage.addMostExpensiveItemToCart();
        homePage.navigateToShoppingCart();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.verifySpecificItemIsInCart(itemName);
    }
}
