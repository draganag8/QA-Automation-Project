package tests;

import dataGenerator.DataProviders;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;
import utilities.PropertyManager;

public class FailedLoginTests extends BaseTest{
    @Test(dataProvider = "FailedLoginDataSet", dataProviderClass = DataProviders.class )
    public void failedLoginTests (String username, String password, String error) {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.performLogin(username, password);
        loginPage.verifyFailedLogin(error);
    }
}
