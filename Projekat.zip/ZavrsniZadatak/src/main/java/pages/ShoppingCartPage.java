package pages;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.sql.SQLOutput;
import java.util.List;

public class ShoppingCartPage extends BasePage{
    public ShoppingCartPage(WebDriver driver) {
        super(driver);
    }

    By removeButtonBy = By.id("remove-sauce-labs-backpack");
    By checkoutButtonBy = By.id("checkout");
    By shoppingCartItemNameBy = By.className("inventory_item_name");

   public void removeItemFromTheCart (){
       driver.findElement(removeButtonBy).click();
    }
    public void shoppingItem (){
        clickElement(checkoutButtonBy);
    }
    public void verifyAddedItemName (String expectedText){
        Assert.assertEquals(readTextFromElement(shoppingCartItemNameBy), expectedText);

}
public void verifyRemovedItem (){
    List<WebElement> listOfElements = driver.findElements(By.id("remove-sauce-labs-backpack"));
    if (listOfElements.isEmpty()){
        System.out.println("Item is removed.");
    } else {
        System.out.println("Item is not removed.");
    }
}
    public void verifySpecificItemIsInCart(String expectedText){
        Assert.assertEquals(readTextFromElement(shoppingCartItemNameBy), expectedText);
    }
}
