package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CheckoutStep3Page extends BasePage{
    public CheckoutStep3Page(WebDriver driver) {
        super(driver);
    }
    By thankYouMessageBy = By.className("complete-header");
    public void verifyShoppingItem (String expectedText){
        Assert.assertEquals(readTextFromElement(thankYouMessageBy), expectedText);
    }
}
