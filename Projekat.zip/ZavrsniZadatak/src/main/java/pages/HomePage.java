package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class HomePage extends BasePage {
    public HomePage(WebDriver driver) {
        super(driver);
    }
    By productsTitleBy = By.className("title");
    By burgerMenuButtonBy = By.className("bm-burger-button");
    By logoutButtonBy = By.id("logout_sidebar_link");
    By addToCartBackpackButtonBy = By.id("add-to-cart-sauce-labs-backpack");
    By shoppingCartButtonBy = By.className("shopping_cart_link");
    By allItemsElementsBy = By.className("inventory_item");
    By inventoryItemNameBy = By.className("inventory_item_name");
    By inventoryItemPriceBy = By.className("inventory_item_price");


    public void verifyLogin (String expextedText){
        Assert.assertEquals(readTextFromElement(productsTitleBy),expextedText);
    }
    public void performLogout (){
        clickElement(burgerMenuButtonBy);
        clickElement(logoutButtonBy);
    }
    public void addItemToTheCart(){
        clickElement(addToCartBackpackButtonBy);
    }
    public void navigateToShoppingCart (){

        clickElement(shoppingCartButtonBy);
    }
    public String addRandomItemToCart(){
        WebElement itemInList = selectRandomWebElement(allItemsElementsBy);
        String itemName = itemInList.findElement(inventoryItemNameBy).getText();
        itemInList.findElement(By.tagName("button")).click();
        return itemName;
    }

    public String addMostExpensiveItemToCart(){
        WebElement mostExpensiveItem = returnMostExpensiveAsWebElement(allItemsElementsBy,inventoryItemPriceBy);
        mostExpensiveItem.findElement(By.tagName("button")).click();
        return mostExpensiveItem.findElement(inventoryItemNameBy).getText();

    }
}
