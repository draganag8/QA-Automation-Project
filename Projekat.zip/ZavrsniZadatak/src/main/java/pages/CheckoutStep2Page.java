package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutStep2Page extends BasePage{
    public CheckoutStep2Page(WebDriver driver) {
        super(driver);
    }
    By finishButtonBy = By.id("finish");

    public void finishShopping (){
        clickElement(finishButtonBy);
    }
}
