package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class CheckoutStep1Page extends BasePage{
    public CheckoutStep1Page(WebDriver driver) {
        super(driver);
    }
    By firstNameFieldBy = By.id("first-name");
    By lastNameFieldBy = By.id("last-name");
    By postalCodeFieldBy = By.id("postal-code");
    By continueButtonBy = By.id("continue");

    public void performShopping (String FirstName, String LastName, String PostalCode)  {
        writeText(firstNameFieldBy, FirstName);
        writeText(lastNameFieldBy, LastName);
        writeText(postalCodeFieldBy, PostalCode);
        clickElement(continueButtonBy);
    }
}
